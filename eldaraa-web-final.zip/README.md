# Eldaraa Web — Starter con diseño steampunk y cartografía

Para correr el proyecto:

```bash
npm install
npm run dev
```